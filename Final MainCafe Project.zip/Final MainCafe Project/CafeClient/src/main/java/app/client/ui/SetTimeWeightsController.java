package app.client.ui;

import app.client.Client;
import app.client.service.Request;
import app.client.service.Response;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

/**
 * Controller for SetTimeWeights.fxml.
 * 1) On initialize(), fetch from server "GET_TIME_WEIGHTS".
 * 2) If mainController's local algorithm is time-weighted, we also init it.
 * 3) On handleOk(), do "SET_TIME_WEIGHTS" on the server.
 */
public class SetTimeWeightsController {

    @FXML private TextField lowField;
    @FXML private TextField midField;
    @FXML private TextField highField;

    private ClientUIController mainController;
    private final Gson gson = new Gson();

    public void setMainController(ClientUIController mainController) {
        this.mainController = mainController;
    }

    /**
     * If local algorithm is time-weighted, we can show existing weights.
     */
    public void initWeights(int[] weights) {
        lowField.setText(String.valueOf(weights[0]));
        midField.setText(String.valueOf(weights[1]));
        highField.setText(String.valueOf(weights[2]));
    }

    @FXML
    private void initialize() {
        fetchTimeWeightsFromServer();
    }

    private void fetchTimeWeightsFromServer() {
        Map<String,String> headers = new HashMap<>();
        headers.put("action","GET_TIME_WEIGHTS");

        String reqJson = gson.toJson(new Request(headers, new HashMap<>()));
        String respStr = Client.sendJsonRequest(reqJson);

        Response r = gson.fromJson(respStr, Response.class);
        if (!r.getMessage().startsWith("SUCCESS:")) {
            System.err.println("Failed to get time weights: " + r.getMessage());
            return;
        }
        String jsonPart = r.getMessage().substring("SUCCESS:".length()).trim();
        Type mapType = new TypeToken<Map<String,Integer>>(){}.getType();
        Map<String,Integer> data = gson.fromJson(jsonPart, mapType);

        int low  = data.getOrDefault("low", 1);
        int mid  = data.getOrDefault("mid", 2);
        int high = data.getOrDefault("high",3);

        lowField.setText(String.valueOf(low));
        midField.setText(String.valueOf(mid));
        highField.setText(String.valueOf(high));
    }

    @FXML
    private void handleOk() {
        try {
            int low  = Integer.parseInt(lowField.getText().trim());
            int mid  = Integer.parseInt(midField.getText().trim());
            int high = Integer.parseInt(highField.getText().trim());

            Map<String,String> headers = new HashMap<>();
            headers.put("action","SET_TIME_WEIGHTS");
            Map<String,String> body = new HashMap<>();
            body.put("low", String.valueOf(low));
            body.put("mid", String.valueOf(mid));
            body.put("high", String.valueOf(high));

            String reqJson = gson.toJson(new Request(headers, body));
            String respStr = Client.sendJsonRequest(reqJson);

            Response r = gson.fromJson(respStr, Response.class);
            if (!r.getMessage().startsWith("SUCCESS")) {
                System.err.println("Failed to set time weights: " + r.getMessage());
            } else {
                System.out.println("Updated time weights on server: [" + low + ", " + mid + ", " + high + "]");
            }
        } catch (NumberFormatException e) {
            System.err.println("Invalid time weights: " + e.getMessage());
        }
        close();
    }

    @FXML
    private void handleCancel() {
        close();
    }

    private void close() {
        Stage st = (Stage) lowField.getScene().getWindow();
        st.close();
    }
}
