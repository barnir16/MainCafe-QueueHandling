package app.client.ui;

import algorithm.BatchItemAlgorithm;
import algorithm.ItemWeightAlgorithm;
import algorithm.MemberPriorityAlgorithm;
import algorithm.TimeBasedAlgorithm;
import algorithm.TimeWeightedAlgorithm;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import app.client.Client;
import app.client.service.Request;
import app.client.service.Response;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import model.Order;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.*;

/**
 * Controller matching MainCafe.fxml.
 * All item and queue data come from the server.
 * Locally we store cartMap for quick display in cartView,
 * and optionally itemWeights for "Change Item Weight."
 */
@SuppressWarnings({"FieldCanBeLocal", "unused"})
public class ClientUIController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label responseLabel;

    @FXML private Label currentAlgorithmLabel;
    @FXML private VBox menuBox;
    @FXML private VBox itemsVBox;
    @FXML private Pane spacer;
    @FXML private CheckBox memberCheckBox;

    @FXML private ListView<String> cartView;
    @FXML private ListView<String> queueView;
    @FXML private ListView<String> processedOrdersView;

    // Local cart data (the server also has its own cart).
    private final Map<String,Integer> cartMap = new HashMap<>();

    // We show the queue & processed in these lists (fetched from server).
    private final ObservableList<String> queueList     = FXCollections.observableArrayList();
    private final ObservableList<String> processedList = FXCollections.observableArrayList();

    // Local item weights, used for "Change Item Weight" if needed.
    private final Map<String,Integer> itemWeights = new HashMap<>();

    private boolean isDarkMode = false;
    private final Gson gson = new Gson();

    @FXML
    public void initialize() {
        // No local default items. The server is the single source of truth.

        if (currentAlgorithmLabel != null) {
            currentAlgorithmLabel.setText("Current Algorithm: Time Based");
        }
        if (queueView != null) {
            queueView.setItems(queueList);
        }
        if (processedOrdersView != null) {
            processedOrdersView.setItems(processedList);
        }

        // Start in light theme
        Platform.runLater(() -> applyDarkMode(false));

        // Immediately fetch from server
        refreshMenuFromServer();
        refreshQueueFromServer();
    }

    // ----------------------------------------------------------------
    // ALGORITHM SWITCH (server-based)
    // ----------------------------------------------------------------
    public void updateAlgorithm(String algName) {
        if (currentAlgorithmLabel != null) {
            currentAlgorithmLabel.setText("Current Algorithm: " + algName);
        }
        Map<String,String> headers = new HashMap<>();
        headers.put("action","SET_ALGORITHM");
        Map<String,String> body = new HashMap<>();
        body.put("algName", algName);

        String resp = Client.sendJsonRequest(gson.toJson(new Request(headers, body)));
        System.out.println("Server alg switch: " + resp);

        // After switching, we refresh the queue to see the new order
        refreshQueueFromServer();
    }

    // ----------------------------------------------------------------
    // CART PLUS / MINUS (server + local)
    // ----------------------------------------------------------------
    @FXML
    private void handleItemPlus(ActionEvent e) {
        Button btn = (Button)e.getSource();
        String itemName = (String)btn.getUserData();

        // Locally
        cartMap.put(itemName, cartMap.getOrDefault(itemName, 0) + 1);
        refreshCartView();

        // Server
        Map<String,String> headers = new HashMap<>();
        headers.put("action","CART_PLUS");
        Map<String,String> body = new HashMap<>();
        body.put("itemName", itemName);

        String resp = Client.sendJsonRequest(gson.toJson(new Request(headers, body)));
        System.out.println("Server CART_PLUS: " + resp);
    }

    @FXML
    private void handleItemMinus(ActionEvent e) {
        Button btn = (Button)e.getSource();
        String itemName = (String)btn.getUserData();

        // Locally
        int count = cartMap.getOrDefault(itemName, 0);
        if (count > 0) {
            count--;
            if (count == 0) {
                cartMap.remove(itemName);
            } else {
                cartMap.put(itemName, count);
            }
            refreshCartView();
        }

        // Server
        Map<String,String> headers = new HashMap<>();
        headers.put("action","CART_MINUS");
        Map<String,String> body = new HashMap<>();
        body.put("itemName", itemName);

        String resp = Client.sendJsonRequest(gson.toJson(new Request(headers, body)));
        System.out.println("Server CART_MINUS: " + resp);
    }

    private void refreshCartView() {
        if (cartView == null) return;
        cartView.getItems().clear();
        for (Map.Entry<String,Integer> e : cartMap.entrySet()) {
            cartView.getItems().add(e.getKey() + " x" + e.getValue());
        }
    }

    // ----------------------------------------------------------------
    // ADD NEW ITEM
    // ----------------------------------------------------------------
    @FXML
    private void handleOpenAddItem() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/app/client/ui/AddNewItem.fxml"));
            Scene scene = new Scene(loader.load());
            addSceneStylesheet(scene);

            AddNewItemController ctrl = loader.getController();
            ctrl.setMainController(this);

            Stage dialog = new Stage();
            dialog.setTitle("Add New Item");
            dialog.setScene(scene);
            dialog.show();
        } catch (IOException e) {
            showError("Failed to open AddNewItem.fxml\n" + e.getMessage());
        }
    }

    public void addItemToMenu(String name, int weight) {
        // Locally store or update itemWeights
        if (itemWeights.containsKey(name)) {
            showInfo("Item already exists: " + name);
            return;
        }
        itemWeights.put(name, weight);

        // Insert in itemsVBox for immediate display
        if (itemsVBox != null) {
            Label lbl = new Label(name);
            Button plus = new Button("+");
            plus.setUserData(name);
            plus.setOnAction(this::handleItemPlus);

            Button minus = new Button("-");
            minus.setUserData(name);
            minus.setOnAction(this::handleItemMinus);

            HBox row = new HBox(10, plus, minus);
            itemsVBox.getChildren().addAll(lbl, row);
        }

        // Tell server
        Map<String,String> headers = new HashMap<>();
        headers.put("action","ADD_ITEM");
        Map<String,String> body = new HashMap<>();
        body.put("name", name);
        body.put("weight", String.valueOf(weight));

        String resp = Client.sendJsonRequest(gson.toJson(new Request(headers, body)));
        System.out.println("Server addItem: " + resp);

        // Re-sync with server
        refreshMenuFromServer();
    }

    // ----------------------------------------------------------------
    // REMOVE ITEM
    // ----------------------------------------------------------------
    @FXML
    private void handleRemoveItem() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/app/client/ui/RemoveItem.fxml"));
            Scene scene = new Scene(loader.load());
            addSceneStylesheet(scene);

            RemoveItemController ctrl = loader.getController();
            ctrl.setMainController(this);

            // Provide local list or fetch from server if needed
            ctrl.initComboBox(new ArrayList<>(itemWeights.keySet()));

            Stage dialog = new Stage();
            dialog.setTitle("Remove Item");
            dialog.setScene(scene);
            dialog.show();
        } catch (IOException e) {
            showError("Failed to open RemoveItem.fxml\n" + e.getMessage());
        }
    }

    public void removeItemFromMenu(String name) {
        itemWeights.remove(name);
        cartMap.remove(name);
        refreshCartView();

        // Remove from itemsVBox
        boolean found = false;
        if (itemsVBox != null) {
            var kids = itemsVBox.getChildren();
            for (int i=0; i<kids.size(); i++) {
                if (kids.get(i) instanceof Label lbl && lbl.getText().equals(name)) {
                    kids.remove(i);
                    if (i < kids.size() && kids.get(i) instanceof HBox) {
                        kids.remove(i);
                    }
                    found = true;
                    break;
                }
            }
        }
        if (!found && menuBox != null) {
            var kids = menuBox.getChildren();
            for (int i=0; i<kids.size(); i++) {
                if (kids.get(i) instanceof Label lbl && lbl.getText().equals(name)) {
                    kids.remove(i);
                    if (i < kids.size() && kids.get(i) instanceof HBox) {
                        kids.remove(i);
                    }
                    break;
                }
            }
        }

        // Tell server
        Map<String,String> headers = new HashMap<>();
        headers.put("action","REMOVE_ITEM");
        Map<String,String> body = new HashMap<>();
        body.put("name", name);

        String resp = Client.sendJsonRequest(gson.toJson(new Request(headers, body)));
        System.out.println("Server removeItem: " + resp);

        refreshMenuFromServer();
    }

    // ----------------------------------------------------------------
    // CHANGE ITEM WEIGHT
    // ----------------------------------------------------------------
    @FXML
    private void handleOpenChangeWeight() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/app/client/ui/ChangeItemWeight.fxml"));
            Scene scene = new Scene(loader.load());
            addSceneStylesheet(scene);

            ChangeItemWeightController ctrl = loader.getController();
            ctrl.setMainController(this);
            ctrl.initItems(new ArrayList<>(itemWeights.keySet()));

            Stage dialog = new Stage();
            dialog.setTitle("Change Item Weight");
            dialog.setScene(scene);
            dialog.show();
        } catch (IOException e) {
            showError("Failed to open ChangeItemWeight.fxml\n" + e.getMessage());
        }
    }

    // ----------------------------------------------------------------
    // REFRESH MENU FROM SERVER
    // ----------------------------------------------------------------
    public void refreshMenuFromServer() {
        Map<String,String> headers = new HashMap<>();
        headers.put("action","GET_MENU");
        String resp = Client.sendJsonRequest(gson.toJson(new Request(headers, new HashMap<>())));
        System.out.println("Server GET_MENU response: " + resp);

        Response r = gson.fromJson(resp, Response.class);
        if (!r.getMessage().startsWith("SUCCESS:")) {
            showError("Failed to get menu: " + r.getMessage());
            return;
        }
        String jsonPart = r.getMessage().substring("SUCCESS:".length()).trim();
        Map<String,Integer> serverItems;
        try {
            serverItems = gson.fromJson(jsonPart, new TypeToken<Map<String,Integer>>(){}.getType());
        } catch(Exception e) {
            System.err.println("Failed parsing menu JSON: " + e.getMessage());
            return;
        }

        // Clear itemsVBox and local itemWeights, then repopulate
        if (itemsVBox != null) {
            itemsVBox.getChildren().clear();
        }
        itemWeights.clear();

        for (Map.Entry<String,Integer> e : serverItems.entrySet()) {
            String itemName = e.getKey();
            itemWeights.put(itemName, e.getValue());

            if (itemsVBox != null) {
                Label lbl = new Label(itemName);
                Button plus = new Button("+");
                plus.setUserData(itemName);
                plus.setOnAction(this::handleItemPlus);

                Button minus = new Button("-");
                minus.setUserData(itemName);
                minus.setOnAction(this::handleItemMinus);

                HBox row = new HBox(10, plus, minus);
                itemsVBox.getChildren().addAll(lbl, row);
            }
        }
    }

    // ----------------------------------------------------------------
    // PLACE / PROCESS / CLEAR => server-based
    // ----------------------------------------------------------------
    @FXML
    private void handlePlaceOrder() {
        if (cartMap.isEmpty()) {
            showInfo("Cart is empty, cannot place an order!");
            return;
        }
        boolean isMember = (memberCheckBox != null && memberCheckBox.isSelected());

        Map<String,String> headers = new HashMap<>();
        headers.put("action","PLACE_ORDER");
        Map<String,String> body = new HashMap<>();
        body.put("member", String.valueOf(isMember));

        String resp = Client.sendJsonRequest(gson.toJson(new Request(headers, body)));
        System.out.println("Server placeOrder: " + resp);

        // Clear local cart
        cartMap.clear();
        refreshCartView();

        refreshQueueFromServer();
    }

    @FXML
    private void handleProcessOrder() {
        Map<String,String> headers = new HashMap<>();
        headers.put("action","PROCESS_ORDER");
        String resp = Client.sendJsonRequest(gson.toJson(new Request(headers, new HashMap<>())));
        System.out.println("Server processOrder: " + resp);

        refreshQueueFromServer();
    }

    @FXML
    private void handleClearProcessed() {
        Map<String,String> headers = new HashMap<>();
        headers.put("action","CLEAR_PROCESSED");
        String resp = Client.sendJsonRequest(gson.toJson(new Request(headers, new HashMap<>())));
        System.out.println("Server clearProcessed: " + resp);

        refreshQueueFromServer();
    }

    // ----------------------------------------------------------------
    // REFRESH QUEUE => server-based
    // ----------------------------------------------------------------
    private void refreshQueueFromServer() {
        Map<String,String> headers = new HashMap<>();
        headers.put("action","GET_QUEUE");
        String resp = Client.sendJsonRequest(gson.toJson(new Request(headers, new HashMap<>())));
        System.out.println("Server GET_QUEUE response: " + resp);

        Response r = gson.fromJson(resp, Response.class);
        if (!r.getMessage().startsWith("SUCCESS:")) {
            System.err.println("Failed to get queue from server: " + r.getMessage());
            return;
        }
        String rawJson = r.getMessage().substring("SUCCESS:".length()).trim();
        try {
            Type mapType = new TypeToken<Map<String,List<String>>>(){}.getType();
            Map<String,List<String>> data = gson.fromJson(rawJson, mapType);

            if (queueView != null) {
                queueList.clear();
                List<String> qList = data.get("queue");
                if (qList != null) queueList.addAll(qList);
            }
            if (processedOrdersView != null) {
                processedList.clear();
                List<String> pList = data.get("processed");
                if (pList != null) processedList.addAll(pList);
            }
        } catch(Exception e) {
            System.err.println("Failed to parse queue data: " + e.getMessage());
        }
    }

    // ----------------------------------------------------------------
    // THEME TOGGLE
    // ----------------------------------------------------------------
    @FXML
    private void handleToggleTheme() {
        isDarkMode = !isDarkMode;
        applyDarkMode(isDarkMode);
    }

    private void applyDarkMode(boolean enable) {
        if (menuBox == null || menuBox.getScene() == null) return;
        Scene mainScene = menuBox.getScene();
        URL lightUrl = getClass().getResource("/css/coffee-light.css");
        URL darkUrl  = getClass().getResource("/css/coffee-dark.css");
        if (lightUrl == null || darkUrl == null) {
            System.err.println("CSS files missing; cannot apply theme.");
            return;
        }
        String lightCss = lightUrl.toExternalForm();
        String darkCss  = darkUrl.toExternalForm();
        mainScene.getStylesheets().removeAll(lightCss, darkCss);
        if (enable) {
            mainScene.getStylesheets().add(darkCss);
        } else {
            mainScene.getStylesheets().add(lightCss);
        }
    }

    private void addSceneStylesheet(Scene scene) {
        URL lightUrl = getClass().getResource("/css/coffee-light.css");
        URL darkUrl  = getClass().getResource("/css/coffee-dark.css");
        if (lightUrl == null || darkUrl == null) {
            System.err.println("CSS files missing.");
            return;
        }
        String lightCss = lightUrl.toExternalForm();
        String darkCss  = darkUrl.toExternalForm();
        if (isDarkMode) {
            scene.getStylesheets().add(darkCss);
        } else {
            scene.getStylesheets().add(lightCss);
        }
    }

    // ----------------------------------------------------------------
    // TIME VALUES / WEIGHTS / ALGORITHM
    // ----------------------------------------------------------------
    @FXML
    private void handleTimeValues() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/app/client/ui/SetTimeValues.fxml"));
            Scene scene = new Scene(loader.load());
            addSceneStylesheet(scene);

            SetTimeValuesController ctrl = loader.getController();
            ctrl.setMainController(this);

            Stage dialog = new Stage();
            dialog.setTitle("Set Time Values");
            dialog.setScene(scene);
            dialog.show();
        } catch (IOException e) {
            showError("Failed to open SetTimeValues.fxml\n" + e.getMessage());
        }
    }

    @FXML
    private void handleTimeWeights() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/app/client/ui/SetTimeWeights.fxml"));
            Scene scene = new Scene(loader.load());
            addSceneStylesheet(scene);

            SetTimeWeightsController ctrl = loader.getController();
            ctrl.setMainController(this);

            Stage dialog = new Stage();
            dialog.setTitle("Set Time Weights");
            dialog.setScene(scene);
            dialog.show();
        } catch (IOException e) {
            showError("Failed to open SetTimeWeights.fxml\n" + e.getMessage());
        }
    }

    @FXML
    private void handleSelectAlgorithm() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/app/client/ui/SelectAlg.fxml"));
            Scene scene = new Scene(loader.load());
            addSceneStylesheet(scene);

            SelectAlgController ctrl = loader.getController();
            ctrl.setMainController(this);

            Stage dialog = new Stage();
            dialog.setTitle("Select Algorithm");
            dialog.setScene(scene);
            dialog.show();
        } catch (IOException e) {
            showError("Failed to open SelectAlg.fxml\n" + e.getMessage());
        }
    }

    // ----------------------------------------------------------------
    // UTILITY
    // ----------------------------------------------------------------
    private void showInfo(String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle("Info");
        a.setHeaderText(null);
        a.setContentText(msg);
        a.showAndWait();
    }

    private void showError(String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR);
        a.setTitle("Error");
        a.setHeaderText(null);
        a.setContentText(msg);
        a.showAndWait();
    }

    // If a "ChangeItemWeightController" calls them
    public int getWeightForItem(String item) {
        return itemWeights.getOrDefault(item, 1);
    }

    public void setWeightForItem(String item, int w) {
        if (itemWeights.containsKey(item)) {
            itemWeights.put(item, w);
        }
    }

    @FXML
    private void handleLogin() {
        System.out.println("Login logic (server) not implemented yet.");
    }

    @FXML
    private void handleRegister() {
        System.out.println("Register logic (server) not implemented yet.");
    }
}
