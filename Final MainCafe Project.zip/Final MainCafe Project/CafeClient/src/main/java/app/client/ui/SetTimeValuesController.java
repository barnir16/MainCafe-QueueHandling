package app.client.ui;

import app.client.Client;
import app.client.service.Request;
import app.client.service.Response;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

/**
 * Controller for SetTimeValues.fxml.
 * 1) On initialize(), fetch from server "GET_TIME_VALUES".
 * 2) If mainController's local algorithm is time-weighted, we also init it.
 * 3) On handleSave(), do "SET_TIME_VALUES" on the server.
 */
public class SetTimeValuesController {

    @FXML private TextField timeLowField;
    @FXML private TextField timeMidField;

    private ClientUIController mainController;
    private final Gson gson = new Gson();

    public void setMainController(ClientUIController mainController) {
        this.mainController = mainController;
    }

    /**
     * If the local algorithm is TimeWeightedAlgorithm, we can show existing thresholds.
     */
    public void initValues(int[] thresholds) {
        timeLowField.setText(String.valueOf(thresholds[0]));
        timeMidField.setText(String.valueOf(thresholds[1]));
    }

    @FXML
    private void initialize() {
        fetchTimeValuesFromServer();
    }

    private void fetchTimeValuesFromServer() {
        Map<String,String> headers = new HashMap<>();
        headers.put("action","GET_TIME_VALUES");

        String reqJson = gson.toJson(new Request(headers, new HashMap<>()));
        String respStr = Client.sendJsonRequest(reqJson);

        Response r = gson.fromJson(respStr, Response.class);
        if (!r.getMessage().startsWith("SUCCESS:")) {
            System.err.println("Failed to get time values: " + r.getMessage());
            return;
        }
        String jsonPart = r.getMessage().substring("SUCCESS:".length()).trim();
        Type mapType = new TypeToken<Map<String,Integer>>(){}.getType();
        Map<String,Integer> data = gson.fromJson(jsonPart, mapType);

        int low = data.getOrDefault("low", 5);
        int mid = data.getOrDefault("mid", 10);

        timeLowField.setText(String.valueOf(low));
        timeMidField.setText(String.valueOf(mid));
    }

    @FXML
    private void handleSave() {
        try {
            int low = Integer.parseInt(timeLowField.getText().trim());
            int mid = Integer.parseInt(timeMidField.getText().trim());

            Map<String,String> headers = new HashMap<>();
            headers.put("action","SET_TIME_VALUES");
            Map<String,String> body = new HashMap<>();
            body.put("low", String.valueOf(low));
            body.put("mid", String.valueOf(mid));

            String reqJson = gson.toJson(new Request(headers, body));
            String respStr = Client.sendJsonRequest(reqJson);

            Response r = gson.fromJson(respStr, Response.class);
            if (!r.getMessage().startsWith("SUCCESS")) {
                System.err.println("Failed to set time values: " + r.getMessage());
            } else {
                System.out.println("Updated time values on server: low=" + low + ", mid=" + mid);
            }
        } catch (NumberFormatException e) {
            System.err.println("Invalid time values: " + e.getMessage());
        }
        close();
    }

    @FXML
    private void handleCancel() {
        close();
    }

    private void close() {
        Stage s = (Stage) timeLowField.getScene().getWindow();
        s.close();
    }
}
