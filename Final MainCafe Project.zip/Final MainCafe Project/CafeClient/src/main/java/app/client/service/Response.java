package app.client.service;

/**
 * Mirrors the server-side Response class:
 * { "message": "...", "data": ...}
 */
public class Response {
    private String message;
    private Object data;  // optional if you want more structured data

    public Response() {
        // For JSON deserialization
    }

    public Response(String message) {
        this.message = message;
    }

    public Response(String message, Object data) {
        this.message = message;
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public Object getData() {
        return data;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setData(Object data) {
        this.data = data;
    }
}
