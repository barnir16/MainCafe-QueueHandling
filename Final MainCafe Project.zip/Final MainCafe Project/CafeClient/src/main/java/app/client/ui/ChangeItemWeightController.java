package app.client.ui;

import app.client.Client;
import app.client.service.Request;
import app.client.service.Response;
import com.google.gson.Gson;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChangeItemWeightController {

    @FXML private ComboBox<String> itemCombo;
    @FXML private TextField weightField;

    private ClientUIController mainController;
    private final Gson gson = new Gson();

    public void setMainController(ClientUIController mc) {
        this.mainController = mc;
    }

    public void initItems(List<String> items) {
        itemCombo.getItems().setAll(items);
        if (!items.isEmpty()) {
            itemCombo.getSelectionModel().selectFirst();
            fetchWeightFor(itemCombo.getValue());
        }
        itemCombo.valueProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                fetchWeightFor(newVal);
            }
        });
    }

    private void fetchWeightFor(String itemName) {
        Map<String,String> headers = new HashMap<>();
        headers.put("action", "GET_ITEM_WEIGHT");
        Map<String,String> body = new HashMap<>();
        body.put("name", itemName);

        String reqJson = gson.toJson(new Request(headers, body));
        String respStr = Client.sendJsonRequest(reqJson);

        Response r = gson.fromJson(respStr, Response.class);
        String msg = r.getMessage();
        if (!msg.startsWith("SUCCESS:")) {
            System.out.println("Failed to get item weight: " + msg);
            return;
        }
        String numberPart = msg.substring("SUCCESS:".length()).trim();
        try {
            int w = Integer.parseInt(numberPart);
            weightField.setText(String.valueOf(w));
        } catch (Exception e) {
            System.out.println("Failed to parse item weight: " + numberPart);
        }
    }

    @FXML
    private void handleApply() {
        String sel = itemCombo.getValue();
        if (sel == null) return;
        int w;
        try {
            w = Integer.parseInt(weightField.getText().trim());
        } catch(Exception e) {
            return;
        }

        Map<String,String> headers = new HashMap<>();
        headers.put("action", "SET_ITEM_WEIGHT");
        Map<String,String> body = new HashMap<>();
        body.put("name", sel);
        body.put("weight", String.valueOf(w));

        String reqJson = gson.toJson(new Request(headers, body));
        String respStr = Client.sendJsonRequest(reqJson);

        Response r = gson.fromJson(respStr, Response.class);
        String msg = r.getMessage();
        if (!msg.startsWith("SUCCESS")) {
            System.out.println("Failed: " + msg);
        } else {
            System.out.println("Weight updated: " + sel + "=" + w);
        }

        if (mainController != null) {
            mainController.refreshMenuFromServer();
        }
        close();
    }

    @FXML
    private void handleCancel() {
        close();
    }

    private void close() {
        Stage s = (Stage) itemCombo.getScene().getWindow();
        s.close();
    }
}
