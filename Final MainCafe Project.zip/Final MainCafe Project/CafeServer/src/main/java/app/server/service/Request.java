package app.server.service;

import java.util.Map;

/**
 * Represents a generic JSON request coming from the client:
 * {
 *   "headers": { "action": "..."},
 *   "body":    { ... }
 * }
 */
public class Request {
    private Map<String, String> headers;
    private Map<String, String> body;

    public Request() {
        // For JSON deserialization
    }

    public Request(Map<String, String> headers, Map<String, String> body) {
        this.headers = headers;
        this.body = body;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }

    public Map<String, String> getBody() {
        return body;
    }

    public void setHeaders(Map<String, String> headers) {
        this.headers = headers;
    }

    public void setBody(Map<String, String> body) {
        this.body = body;
    }
}
