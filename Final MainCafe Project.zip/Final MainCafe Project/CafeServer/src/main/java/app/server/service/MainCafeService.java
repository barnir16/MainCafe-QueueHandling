package app.server.service;

import app.server.dao.IDao;
import app.server.dao.MyDMFileImpl;
import app.shared.User;
import algorithm.BatchItemAlgorithm;
import algorithm.ItemWeightAlgorithm;
import algorithm.MemberPriorityAlgorithm;
import algorithm.TimeBasedAlgorithm;
import algorithm.TimeWeightedAlgorithm;
import model.Order;
import queue.IQueueAlgorithm;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

/**
 * Manages users, items, a cart, processed orders, and a queue algorithm.
 * Also stores time thresholds and weights so we can handle them
 * even if the current algorithm is not time-weighted.
 */
public class MainCafeService {
    private static final Logger logger = Logger.getLogger(MainCafeService.class.getName());
    private final IDao<User> dao;

    private final Map<String,Integer> items = new HashMap<>();
    private final Map<String,Integer> cart  = new HashMap<>();
    private final List<Order> processedOrders = new ArrayList<>();

    private IQueueAlgorithm currentAlg;
    private int[] timeThresholds = {5, 10};
    private int[] timeWeights    = {1, 2, 3};

    // Incremental ID for orders
    private static int nextOrderId = 1;

    public MainCafeService() {
        this.dao = new MyDMFileImpl("users.txt");
        currentAlg = new TimeBasedAlgorithm();
        items.put("Cappuccino", 2);
        items.put("Espresso",   1);
        items.put("Sandwich",   3);
    }

    public MainCafeService(IDao<User> dao) {
        this.dao = dao;
        currentAlg = new TimeBasedAlgorithm();
    }

    public boolean saveUser(String username, String password) {
        User existing = dao.find(username);
        if (existing != null) {
            logger.warning("User '" + username + "' already exists.");
            return false;
        }
        return dao.save(new User(username, password));
    }

    public User findUser(String username) {
        return dao.find(username);
    }

    public boolean addItem(String name, int weight) {
        if (name == null || name.isBlank() || weight <= 0) return false;
        if (items.containsKey(name)) return false;
        items.put(name, weight);
        return true;
    }

    public boolean removeItem(String name) {
        if (name == null || !items.containsKey(name)) return false;
        items.remove(name);
        return true;
    }

    public Map<String,Integer> getAllItems() {
        return new HashMap<>(items);
    }

    public int getItemWeight(String name) {
        return items.getOrDefault(name, 1);
    }

    public boolean updateItemWeight(String name, int newWeight) {
        if (newWeight <= 0 || !items.containsKey(name)) {
            return false;
        }
        items.put(name, newWeight);
        if (currentAlg instanceof ItemWeightAlgorithm iwa) {
            iwa.setItemWeight(name, newWeight);
            logger.info("Updated ItemWeightAlgorithm for '" + name + "' => " + newWeight);
        }
        return true;
    }

    public boolean setAlgorithm(String algName) {
        // 1) Copy existing orders
        List<Order> oldOrders = new ArrayList<>(currentAlg.getQueue());

        switch (algName) {
            case "Batch Item":
                currentAlg = new BatchItemAlgorithm();
                break;
            case "Member Priority":
                currentAlg = new MemberPriorityAlgorithm();
                break;
            case "Item Weight":
                ItemWeightAlgorithm iwa = new ItemWeightAlgorithm();
                iwa.setTimeThresholds(timeThresholds[0], timeThresholds[1]);
                iwa.setWeights(timeWeights[0], timeWeights[1], timeWeights[2]);
                for (Map.Entry<String, Integer> e : items.entrySet()) {
                    iwa.setItemWeight(e.getKey(), e.getValue());
                }
                currentAlg = iwa;
                break;
            default:
                currentAlg = new TimeBasedAlgorithm();
                break;
        }
        if (currentAlg instanceof TimeWeightedAlgorithm twa) {
            twa.setTimeThresholds(timeThresholds[0], timeThresholds[1]);
            twa.setWeights(timeWeights[0], timeWeights[1], timeWeights[2]);
        }

        // 2) Re-add old orders to the new algorithm
        for (Order o : oldOrders) {
            currentAlg.addOrder(o);
        }
        return true;
    }

    public boolean setTimeValues(int low, int mid) {
        if (low < 1 || mid < 1 || low >= mid) {
            return false;
        }
        timeThresholds[0] = low;
        timeThresholds[1] = mid;
        if (currentAlg instanceof TimeWeightedAlgorithm twa) {
            twa.setTimeThresholds(low, mid);
        }
        return true;
    }

    public boolean setTimeWeights(int low, int mid, int high) {
        if (low <= 0 || mid <= 0 || high <= 0) {
            return false;
        }
        timeWeights[0] = low;
        timeWeights[1] = mid;
        timeWeights[2] = high;
        if (currentAlg instanceof TimeWeightedAlgorithm twa) {
            twa.setWeights(low, mid, high);
        }
        return true;
    }

    public int[] getTimeValues() {
        return new int[]{ timeThresholds[0], timeThresholds[1] };
    }

    public int[] getTimeWeights() {
        return new int[]{ timeWeights[0], timeWeights[1], timeWeights[2] };
    }

    public String getAlgorithmName() {
        if (currentAlg instanceof BatchItemAlgorithm) return "Batch Item";
        if (currentAlg instanceof MemberPriorityAlgorithm) return "Member Priority";
        if (currentAlg instanceof ItemWeightAlgorithm)     return "Item Weight";
        return "Time Based";
    }

    public boolean cartPlus(String itemName) {
        if (itemName == null || itemName.isBlank()) return false;
        cart.put(itemName, cart.getOrDefault(itemName, 0) + 1);
        return true;
    }

    public boolean cartMinus(String itemName) {
        if (itemName == null || !cart.containsKey(itemName)) return false;
        int c = cart.get(itemName);
        if (c <= 0) return false;
        if (c == 1) {
            cart.remove(itemName);
        } else {
            cart.put(itemName, c - 1);
        }
        return true;
    }

    public Map<String,Integer> getCartItems() {
        return new HashMap<>(cart);
    }

    public boolean placeOrder(boolean isMember) {
        if (cart.isEmpty()) {
            logger.warning("Cart is empty - cannot place order.");
            return false;
        }
        int newId = nextOrderId++;
        Order newOrder = new Order(newId, new HashMap<>(cart), isMember);
        newOrder.setTimePlaced(LocalDateTime.now());
        logger.info("Placing new Order ID=" + newId + " with items " + cart);
        currentAlg.addOrder(newOrder);
        cart.clear();
        return true;
    }

    public boolean processOrder() {
        if (currentAlg.getQueue().isEmpty()) {
            logger.info("Queue is empty, no order was processed.");
            return false;
        }
        logger.info("Queue before processing: " + currentAlg.getQueue());
        if (currentAlg instanceof TimeWeightedAlgorithm twa) {
            for (Order o : currentAlg.getQueue()) {
                int timeW = twa.calculateTimeWeight(o);
                int itemW = 0;
                if (twa instanceof ItemWeightAlgorithm iwa) {
                    itemW = o.getItems().entrySet()
                            .stream()
                            .mapToInt(e -> e.getValue() * iwa.getItemWeight(e.getKey()))
                            .sum();
                }
                int total = timeW + itemW;
                logger.info("Order " + o.getOrderId()
                        + " => timeWeight=" + timeW
                        + ", itemWeight=" + itemW
                        + ", total=" + total);
            }
        }
        Order next = currentAlg.processNextOrder();
        if (next == null) {
            logger.info("No order chosen by the algorithm.");
            return false;
        }
        next.setTimeProcessed(LocalDateTime.now());
        processedOrders.add(next);
        logger.info("Order chosen/processed: " + next);
        return true;
    }

    public boolean clearProcessed() {
        processedOrders.clear();
        return true;
    }

    public Map<String,List<String>> getQueueData() {
        Map<String,List<String>> map = new HashMap<>();
        List<String> queueList = new ArrayList<>();
        for (Order o : currentAlg.getQueue()) {
            queueList.add(o.toString());
        }
        List<String> procList = new ArrayList<>();
        for (Order p : processedOrders) {
            procList.add(p.toString());
        }
        map.put("queue", queueList);
        map.put("processed", procList);
        return map;
    }
}
