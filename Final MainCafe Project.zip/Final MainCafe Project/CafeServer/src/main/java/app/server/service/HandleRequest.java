package app.server.service;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Server side: returns a JSON object with a "message" field that
 * can begin with "SUCCESS" or "ERROR". The client parses that
 * into a Response object. Also supports cart, items, queue,
 * time values, etc.
 */
public class HandleRequest implements Runnable {
    private static final Logger logger = Logger.getLogger(HandleRequest.class.getName());
    private final Socket clientSocket;
    private final MainCafeService service;
    private final Gson gson = new Gson();

    public HandleRequest(Socket c, MainCafeService s) {
        this.clientSocket = c;
        this.service = s;
    }

    @Override
    public void run() {
        try (Scanner reader = new Scanner(new InputStreamReader(clientSocket.getInputStream()));
             PrintWriter writer = new PrintWriter(new OutputStreamWriter(clientSocket.getOutputStream()), true)) {

            while (reader.hasNextLine()) {
                String jsonReq = reader.nextLine();
                logger.info("Request: " + jsonReq);

                Request req = gson.fromJson(jsonReq, new TypeToken<Request>(){}.getType());
                Response res = processRequest(req);

                String jsonRes = gson.toJson(res);
                writer.println(jsonRes);
            }
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error in HandleRequest run()", e);
        }
    }

    public Response processRequest(Request req) {
        if (req == null || req.getHeaders() == null) {
            return new Response("ERROR: Bad request");
        }
        String action = req.getHeaders().get("action");
        if (action == null) {
            return new Response("ERROR: No action");
        }

        switch (action) {
            case "LOGIN":
                return handleLogin(req);
            case "REGISTER":
                return handleRegister(req);

            case "saveUser":
                return handleSaveUser(req);
            case "findUser":
                return handleFindUser(req);

            case "SET_ALGORITHM":
                return handleSetAlgorithm(req);
            case "SET_TIME_VALUES":
                return handleSetTimeValues(req);
            case "SET_TIME_WEIGHTS":
                return handleSetTimeWeights(req);
            case "GET_TIME_VALUES":
                return handleGetTimeValues(req);
            case "GET_TIME_WEIGHTS":
                return handleGetTimeWeights(req);

            case "ADD_ITEM":
                return handleAddItem(req);
            case "REMOVE_ITEM":
                return handleRemoveItem(req);
            case "GET_MENU":
                return handleGetMenu(req);

            case "CART_PLUS":
                return handleCartPlus(req);
            case "CART_MINUS":
                return handleCartMinus(req);
            case "GET_CART":
                return handleGetCart(req);
            case "PLACE_ORDER":
                return handlePlaceOrder(req);
            case "PROCESS_ORDER":
                return handleProcessOrder(req);
            case "CLEAR_PROCESSED":
                return handleClearProcessed(req);
            case "GET_QUEUE":
                return handleGetQueue(req);

            case "GET_ITEM_WEIGHT":
                return handleGetItemWeight(req);
            case "SET_ITEM_WEIGHT":
                return handleSetItemWeight(req);

            case "GET_ALG_NAME":
                return new Response("SUCCESS:" + service.getAlgorithmName());

            default:
                return new Response("ERROR: Unknown action");
        }
    }

    private Response handleLogin(Request req) {
        Map<String,String> body = req.getBody();
        if (body == null) return new Response("ERROR: Body is null");
        String username = body.get("username");
        String password = body.get("password");
        if (username == null || username.isBlank() ||
                password == null || password.isBlank()) {
            return new Response("ERROR: Missing username/password");
        }
        UserService userService = new UserService();
        boolean authenticated = userService.authenticate(username, password);
        if (authenticated) {
            return new Response("SUCCESS");
        } else {
            return new Response("ERROR: Invalid credentials");
        }
    }

    private Response handleRegister(Request req) {
        Map<String,String> body = req.getBody();
        if (body == null) return new Response("ERROR: Body is null");
        String username = body.get("username");
        String password = body.get("password");
        if (username == null || username.isBlank() ||
                password == null || password.isBlank()) {
            return new Response("ERROR: Username/password cannot be empty");
        }
        UserService userService = new UserService();
        boolean registered = userService.register(username, password);
        if (registered) {
            return new Response("REGISTERED");
        } else {
            return new Response("ERROR: Duplicate or invalid user");
        }
    }

    private Response handleSaveUser(Request req) {
        Map<String,String> body = req.getBody();
        if (body == null) return new Response("ERROR: Body is null");
        String username = body.get("username");
        String password = body.get("password");
        if (username == null || username.isBlank() ||
                password == null || password.isBlank()) {
            return new Response("ERROR: Missing username/password");
        }
        boolean saved = service.saveUser(username, password);
        if (saved) {
            return new Response("SAVED");
        } else {
            return new Response("ERROR: Could not save user");
        }
    }

    private Response handleFindUser(Request req) {
        Map<String,String> body = req.getBody();
        if (body == null) return new Response("ERROR: Body is null");
        String username = body.get("username");
        if (username == null || username.isBlank()) {
            return new Response("ERROR: Missing username");
        }
        var user = service.findUser(username);
        if (user == null) {
            return new Response("NOT FOUND");
        } else {
            return new Response("FOUND: " + user.getUsername());
        }
    }

    private Response handleSetAlgorithm(Request req) {
        Map<String,String> body = req.getBody();
        if (body == null) return new Response("ERROR: No body");
        String algName = body.get("algName");
        if (algName == null) return new Response("ERROR: No algName");
        boolean ok = service.setAlgorithm(algName);
        return ok ? new Response("SUCCESS: Algorithm set")
                : new Response("ERROR: Invalid algorithm");
    }

    private Response handleSetTimeValues(Request req) {
        Map<String,String> body = req.getBody();
        if (body == null) return new Response("ERROR: No body");
        try {
            int low = Integer.parseInt(body.get("low"));
            int mid = Integer.parseInt(body.get("mid"));
            boolean ok = service.setTimeValues(low, mid);
            if (ok) return new Response("SUCCESS: Time values updated");
        } catch(Exception e) {
            return new Response("ERROR: " + e.getMessage());
        }
        return new Response("ERROR: Could not set time values");
    }

    private Response handleSetTimeWeights(Request req) {
        Map<String,String> body = req.getBody();
        if (body == null) return new Response("ERROR: No body");
        try {
            int lo = Integer.parseInt(body.get("low"));
            int mi = Integer.parseInt(body.get("mid"));
            int hi = Integer.parseInt(body.get("high"));
            boolean ok = service.setTimeWeights(lo, mi, hi);
            if (ok) return new Response("SUCCESS: Time weights updated");
        } catch(Exception e) {
            return new Response("ERROR: " + e.getMessage());
        }
        return new Response("ERROR: Could not set time weights");
    }

    private Response handleGetTimeValues(Request req) {
        int[] vals = service.getTimeValues();
        Map<String,Integer> map = new HashMap<>();
        map.put("low", vals[0]);
        map.put("mid", vals[1]);
        String json = new Gson().toJson(map);
        return new Response("SUCCESS:" + json);
    }

    private Response handleGetTimeWeights(Request req) {
        int[] w = service.getTimeWeights();
        Map<String,Integer> map = new HashMap<>();
        map.put("low",  w[0]);
        map.put("mid",  w[1]);
        map.put("high", w[2]);
        String json = new Gson().toJson(map);
        return new Response("SUCCESS:" + json);
    }

    private Response handleGetItemWeight(Request req) {
        Map<String,String> body = req.getBody();
        if (body == null) {
            return new Response("ERROR: Body is null");
        }
        String name = body.get("name");
        if (name == null || name.isBlank()) {
            return new Response("ERROR: Missing item name");
        }
        int w = service.getItemWeight(name);
        return new Response("SUCCESS:" + w);
    }

    private Response handleAddItem(Request req) {
        Map<String,String> body = req.getBody();
        if (body == null) return new Response("ERROR: Body null");
        try {
            String name = body.get("name");
            int w = Integer.parseInt(body.get("weight"));
            boolean ok = service.addItem(name, w);
            return ok ? new Response("SUCCESS: Item added")
                    : new Response("ERROR: Could not add item");
        } catch(Exception e) {
            return new Response("ERROR: " + e.getMessage());
        }
    }

    private Response handleRemoveItem(Request req) {
        Map<String,String> body = req.getBody();
        if (body == null) return new Response("ERROR: Body null");
        String name = body.get("name");
        boolean ok = service.removeItem(name);
        return ok ? new Response("SUCCESS: Item removed")
                : new Response("ERROR: Could not remove item");
    }

    private Response handleGetMenu(Request req) {
        Map<String,Integer> menu = service.getAllItems();
        String jsonMenu = new Gson().toJson(menu);
        return new Response("SUCCESS:" + jsonMenu);
    }

    private Response handleCartPlus(Request req) {
        Map<String,String> body = req.getBody();
        if (body == null) return new Response("ERROR: Body is null");
        String itemName = body.get("itemName");
        boolean ok = service.cartPlus(itemName);
        return ok ? new Response("SUCCESS: Cart plus done")
                : new Response("ERROR: cart plus failed");
    }

    private Response handleCartMinus(Request req) {
        Map<String,String> body = req.getBody();
        if (body == null) return new Response("ERROR: Body is null");
        String itemName = body.get("itemName");
        boolean ok = service.cartMinus(itemName);
        return ok ? new Response("SUCCESS: Cart minus done")
                : new Response("ERROR: cart minus failed");
    }

    private Response handleGetCart(Request req) {
        Map<String,Integer> c = service.getCartItems();
        List<String> arr = new ArrayList<>();
        for (var e : c.entrySet()) {
            arr.add(e.getKey() + " x" + e.getValue());
        }
        String json = new Gson().toJson(arr);
        return new Response("SUCCESS:" + json);
    }

    private Response handlePlaceOrder(Request req) {
        Map<String,String> body = req.getBody();
        if (body == null) return new Response("ERROR: Body is null");
        boolean isMember = Boolean.parseBoolean(body.getOrDefault("member","false"));
        boolean ok = service.placeOrder(isMember);
        return ok ? new Response("SUCCESS: Order placed")
                : new Response("ERROR: placeOrder failed (cart empty?)");
    }

    private Response handleProcessOrder(Request req) {
        boolean ok = service.processOrder();
        return ok ? new Response("SUCCESS: Order processed")
                : new Response("ERROR: queue empty or process failed");
    }

    private Response handleClearProcessed(Request req) {
        boolean ok = service.clearProcessed();
        return ok ? new Response("SUCCESS: processed cleared")
                : new Response("ERROR: could not clear processed");
    }

    private Response handleGetQueue(Request req) {
        Map<String,List<String>> qData = service.getQueueData();
        String json = new Gson().toJson(qData);
        return new Response("SUCCESS:" + json);
    }

    private Response handleSetItemWeight(Request req) {
        Map<String,String> body = req.getBody();
        if (body == null) return new Response("ERROR: Body null");
        String name = body.get("name");
        String wStr = body.get("weight");
        try {
            int w = Integer.parseInt(wStr);
            boolean ok = service.updateItemWeight(name, w);
            return ok ? new Response("SUCCESS: Weight updated")
                    : new Response("ERROR: Could not update weight");
        } catch(Exception e) {
            return new Response("ERROR: " + e.getMessage());
        }
    }
}
